/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "apxwin.h"
#include "private.h"

#define EXE_SUFFIX      L".EXE"
#define EXE_SUFFIXLEN   (sizeof(EXE_SUFFIX) / sizeof(WCHAR) - 1)

#define X86_SUFFIX      L".X86"
#define X64_SUFFIX      L".X64"

/* Those two are declared in handles.c */
extern LPWSTR   *_st_sys_argvw;
extern int      _st_sys_argc;

static WCHAR    _st_sys_appexe[MAX_PATH];
/*
 * argv parsing.
 * Parse the argv[0] and split to ExePath and
 * Executable name. Strip the extension ('.exe').
 * Check for command in argv[1] //CMD//Application
 * Parse the options --option value or --option==value
 * break on first argument that doesn't start with '--'
 */
LPAPXCMDLINE apxCmdlineParse(
    APXHANDLE hPool,
    APXCMDLINEOPT   *lpOptions,
    LPCWSTR         *lpszCommands,
    LPCWSTR         *lpszAltcmds)
{

    LPAPXCMDLINE lpCmdline = NULL;
    DWORD l, i, s = 1;
    LPWSTR p;
    DWORD  match;
    WCHAR  mh[SIZ_HUGLEN];

    if (_st_sys_argc < 1)
        return NULL;

    if (!(lpCmdline = (LPAPXCMDLINE)apxPoolCalloc(hPool, sizeof(APXCMDLINE))))
        return NULL;
    lpCmdline->hPool     = hPool;
    lpCmdline->lpOptions = lpOptions;
    if (GetModuleFileNameW(GetModuleHandle(NULL), mh, SIZ_HUGLEN)) {
        GetLongPathNameW(mh, mh, SIZ_HUGLEN);
        lpCmdline->szExePath = apxPoolStrdupW(hPool, mh);
        lpCmdline->szArgv0   = apxPoolStrdupW(hPool, mh);
        if (lpCmdline->szExePath == NULL || lpCmdline->szArgv0 == NULL)
            return NULL;
        if ((p = wcsrchr(lpCmdline->szExePath, L'\\')))
            *p++ = L'\0';
        else
            return NULL;
    }
    else
        return NULL;
    lpCmdline->szExecutable = p;
    p = wcsrchr(lpCmdline->szExecutable, L'.');
    if (p && lstrcmpiW(p, EXE_SUFFIX) == 0)
        *p = L'\0';
    if ((p = wcsrchr(lpCmdline->szExecutable, L'.'))) {
        if (lstrcmpiW(p, X86_SUFFIX) == 0) {
            *p = L'\0';
        }
        else if (lstrcmpiW(p, X64_SUFFIX) == 0) {
            *p = L'\0';
        }
    }
    if (_st_sys_argc > 1 && lstrlenW(_st_sys_argvw[1]) > 2) {
        LPWSTR cp = _st_sys_argvw[1];
        LPWSTR cn = _st_sys_argc > 2 ? _st_sys_argvw[2] : NULL;
        LPWSTR ca = cp;
        i = 0;
        if (ca[0] == L'/' && ca[1] == L'/') {
            ca += 2;
            if ((cn = wcschr(ca, L'/'))) {
                *cn++ = L'\0';
                while (*cn == L'/')
                    cn++;
                if (*cn == L'\0')
                    cn = NULL;
            }
            if (cn == NULL)
                cn = lpCmdline->szExecutable;
            while (lpszCommands[i]) {
                if (lstrcmpW(lpszCommands[i++], ca) == 0) {
                    lpCmdline->dwCmdIndex = i;
                    break;
                }
            }
            if (lpCmdline->dwCmdIndex) {
                lpCmdline->szApplication = cn;
                s = 2;
            }
            else {
                apxLogWrite(APXLOG_MARK_ERROR "Unrecognized cmd option %S"
  
        
                  ewce.h         f cn++;
                if (*cn == L'\0')
         p       RdupW(hPool,*cn           Lo          Gicense.
\par }}                     }{\f38\froman\fcharset204\*cn == L    PXBEGIN_DECLS

#de1
\p      Rdrn
  
  0an\fch8\froma1
\S
\S|s                                                  
    0x000000                         1  0x000000 EGIN_DE         ;
    lpCmdli
#i(  ifs;   < rkingP) * WITHOUT WA ) {    return NULL;
  e0';
        }
    __FILE}
    else
    i   return NU
BOOLdd}
, APX(p && lstrcmpiWp, EXE_SUF+IX) = 0)
     +0) {
          Ldd}
_MAR NULL;
    lpCcmpiWp, EX!    -'f (_ 0)
!    -') {
                    }
    }
if ication = cn;in Fie "afine EXE_SUFtris '='  an  {
       *i
#iefine EXE_SUFFI
#define EX".EXE"cases. {
       */ {
              p       }
       X64_Sp
     =  *p = L'\0';
       *csrchr(lpCmdline->szLL;
    GetMf i1Cmdline->szLL;
             }
           RdupW(hPool,*cnmdline->szLL;
   p {
             RdupW(h] and if (p && lstrc
#i(ld.
 *XCMDLINE [l].
 * li *X {    return NU    X64_mmands[i++]MDLINE [l].
 * li,
if ic                 lpCmdline-  __FIL.EXCmdline->szLL;
   in c */
X64
 nse 1
#}{\*/ {
      n NU    X64_e) {
            *p = L.EXd.)
         p   Pool,*cnmdlineif i1) < rkingP) * WITHOUT W) {
            *p = L.EXd.    else
    ++i   return NUp   Pool,*cnm         lpCmdline->dwCmdMDLINE [l].try, DW if (p && lstrcCmdline->dwCmdMDLINE [l].szValue0';
        }
    }ine->dwCmdMDLINE [l].triceC |=* ThoseOPT_FOUND         break;
                }
            }
               mpiWpdd       }
            elsommand iMDLINE [l].triceC &* ThoseOPT_FOUND        }
            elsssssin Ox000 hPoLdd}flag     aefine re wis nodefine EX    }
            elsssss\*/ {
      n NU            mdMDLINE [l].triceC |=* ThoseOPT_ADD         break;
       }
               n %S"
  
        
   ->dwCmdMDLINE [l].triceC &* ThoseOPT_ADD       }
            elsin W thive ++ine EX"efine EX"ate

            elsssss\* Disctlpaearlier".EXE" Lice go ou ue

            elsssss\*/ {
      n NU         mdMDLINE [l].triceC &= ~ ThoseOPT_ADD         break;
      CmdMDLINE [l].try, DW if (p && lstrcCmdline->dwCCmdMDLINE [l].szValue0'; (p && lstrcCmdline- }
               mpiWmdMDLINE [l].triceC &* ThoseOPT__FI) {
            *p = LmdMDLINE [l].szValue0';.EXCmdline->szLL;
   
   ->dwCmdMDLINE [l].triceC &* ThoseOPT_INT) {
            *p = LmdMDLINE [l].try, DW ifrkingP)   AtoulW(.EXt204\*cn == L    PXB
   ->dwCmdMDLINE [l].triceC &* ThoseOPT_MSZ       }
            els.
 * Pap(p && lstrcCmdline->dwC
BOOinsquote}
, APX,Oindquote=, APX(p && lstrccccccccccccc argv[sp if (p && lstrcCmdline->dwC.
 * PovPAPXCMDLINE [l].szValue(p && lstrcCmdline->dwC>dwCmdMDLINE [l].try, DW        return NUUUUUUUUUUUUUUUUUsp ifCmdMDLINE [l].try, DW -www.apache.org://www.apache.org         break;
       }
                   mdMDLINE [l].try, DW ifrsMf iL'\0';
 .EXtf ic  *www.apache.org         break;
      mdMDLINE [l].szValue0';(.
 * ation
 * Parse the o    }
            elsssss\\\\\\\\\\\\\\\\\\\\\\\\mdMDLINE [l].try, DWg         break;
      >dwCsp       }
                   AplMou Memory++]MDLINE [l].
 y, DW,Pov,Usp *www.apache.orgg         break;
          tioFree(ovg         break;
       }
                   pp0';.EXCmdline->szLL;
       uage g*pp       }
                   X64_Spp
     \'0) {
            *p = L        Xnsquote}
!Xnsquote         break;
          
   ->dwCSpp
     "  *p = L'\0';
        = L        Xndquote}
!Xndquote         break;
              +]MDLINE [l].
 y, DW[sp {]     "          break;
           }
                       
   ->dwCCSpp
     #'f (_Spp
     ;  *) =!Xnsquote*) =!Xndquote) {
            *p = L        +]MDLINE [l].
 y, DW[sp {]     (lpCmdline->szLL;
           
    {
            *p = L        +]MDLINE [l].
 y, DW[sp {]   *ap(p && lstrcCmdline->dwCCCCCpp {
                apxLo }
               n %S"
  
        mdMDLINE [l].triceC |=* ThoseOPT_FOUND         break;
  ] and iflf i1Cmdline->szLL;
             }
           RdupW(h    RdupW(h>dwC] and i              lpCmdlin --unknown ine EX    }
        *    }
        */ {
      n NU   Gicense.
\par }}                     }{\program\froman\fchap && lstrcCmdline->dwCCCCC    else
    i g         break;EGIN_DECLS

#de1
\pExePath, L'\\')))  < rkingP) * WITHOUT W)
\S
\S|s               APXHANlpCmdline->szExe-           brrt with '--' 1)wlpC&    else
    i   retur, L'\\'EGIN_DE         ;
} to in Utive
#ifuIN_atiopa under*/ {LSE, NUL       Free( L'\\'atic WCHAR    _st_sys__argc;

sttioFree( _st_sys__;
} to ining pstry keys
 */
APXsied.
 *ing pand  */
APXHAsie APXL121  0  PR_ing 
#iexampPXH' hPoPR_JVM=rars'tris aXREGe meander asie ovi     '--Jvm rars'ing oNY KINnclude "}}   ing Multi-spxDel
 */
APXsioftwLddive-src/wiegarys
conf"); you LSE, NUL       LoadpstVd.( L'\\'atic WCHAR    _st_sys__argc;'\\'to Exeszpst[64   retur BAS  if (p && lomman in argv[1 (_!rt with '--'
 */
L or --option==val;c;

stnds[i]) { with '--'
 */
L i .
 * li)
\S
\S|s    H];
/*         brto ExeszVd.h and
 * Execu      brr'\0'cpyW(szpst, 64, L"PR_")ecu      brr'\0'catW(szpst, 64,  { with '--'
 */
L i .
 * li)ecu      brr ifGetpstry keysV*/
APXW(szpst, szVd.ds,
    MAX match;
    WCHA i   f (_s >=s,
    MAX    return NU    X64_m                lpCmdline-ineParsLastANDLE           _ENVVAR_NOT_FOUND       }
            elsi/ Ex    it000clearmitatiNDLE 
   ->)
llne Aloggive-h  {
            *p = Li/ o\ad d on aXlog me);
HAsidatiteX    }
            elsSrsLastANDLE 0g         break;
  }l,*cnm         lpCmdline->dwC   Gicense.
\par }}           ANDLE getion gistry keys
 */
APXHfchap && lstrcCmdline->dwCCCCCCCCCCCCCszpstg         break;
      n==val;c;      break;
  }    }
           RdupW(hPool++          break;    inue(p && lstrc    RdupW(h>dwC { with '--'
 */
L i .triceC &* ThoseOPT__FI)m         lpCmdl { with '--'
 */
L i .
 Value0';   LPWSTR p;
  on first argume, szVd.g         break; { with '--'
 */
L i .triceC |=* ThoseOPT_FOUND         brine->szArgv0 == NULL){ with '--'
 */
L i .triceC &* ThoseOPT_INT)m         lpCmdl { with '--'
 */
L i .try, DW ifrkingP)   AtoulW(szVd.g         break; { with '--'
 */
L i .triceC |=* ThoseOPT_FOUND         brine->szArgv0 == NULL){ with '--'
 */
L i .triceC &* ThoseOPT_MSZ       }
       .
 * Pap(p && lstrcCmdl
BOOinsquote}
, APX,Oindquote}
, APX(p && lstrccccc argv[sp if (p && lstrcCmdl { with '--'
 */
L i .try, DW ifrL'\0';
 szVd.gf ic  *www.apache.org         break; { with '--'
 */
L i .
 Value0';   LPWS* Parse on first argume,    }
            elsssss\\\\\\\\\\\\\\\\\\\\\\\\Cmdl { with '--'
 */
L i .try, DWg         break;pp0';szVd.TR cp = _st_sys_argvg*pp       }
           X64_Spp
     \'0) {
            *p = LXnsquote}
!Xnsquote         break;
  
   ->dwCSpp
     "  *p = L'\0';
        = LXndquote}
!Xndquote         break;
       { with '--'
 */
L i .
 Value[sp {]     "          break;
  n %S"
  
        
   ->dwCCSpp
     #'f (_Spp
     ;  *) =!Xnsquote*) =!Xndquote) {
            *p = L { with '--'
 */
L i .
 Value[sp {]     (lpCmdline->szLL;
                      ewce.h         f c'
 */
L i .
 Value[sp {]   *ap(p && lstrcCmdline-pp {
             }        break; { with '--'
 */
L i .triceC |=* ThoseOPT_FOUND |* ThoseOPT_ADD         br}        br++        } to }                        LPCWSTR szDisplayName, LPCWSTR szImagePath,
                              LPCWSTR lpDependencies, DWORD dwServiceType,
                              DWORD dwStartType);

LPAPXSERVENTRY  apxServiceEntry(APXHANDLE hService, BOOL bReeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeid16132583 imitations under the License.
\pa132ol                                                        